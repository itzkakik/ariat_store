# ARIAT Prototype Store (React + TypeScript + Vite)
Run: `npm install` then `npm run dev` (build check: `npm run build`).
- Products: edit `src/data/products.ts` (all sample data).
- Images: put `SKU.jpg` (and optional `SKU_2.jpg`...) in `src/assets/products/`.
- Free-shipping threshold and shipping fees: `src/utils.ts`.
- Demo store; payments are simulated.
