export type Gender='men'|'women'|'kids';
export type Category='Boots'|'Shoes'|'Shirts'|'Jackets'|'Jeans'|'Accessories'|'Clothing';
export type Delivery='standard'|'express';
export type Payment='Cash on Delivery'|'GCash'|'Maya'|'Credit/Debit Card';
export type OrderStatus='Pending'|'Confirmed'|'Processing'|'Shipped'|'Delivered'|'Cancelled';
export interface Variant{size:string;color:string;stock:number}
export interface Product{id:string;sku:string;name:string;description:string;brand:string;gender:Gender;category:Category;
 price:number;salePrice?:number;variants:Variant[];rating:number;reviewCount:number;tags:string[];materials:string;care:string;
 isNew?:boolean;isFeatured?:boolean}
export interface CartItem{sku:string;size:string;color:string;qty:number;saved?:boolean}
export interface Customer{firstName:string;lastName:string;email:string;phone:string}
export interface Address{unit:string;street:string;barangay:string;city:string;province:string;postal:string;country:string}
export interface CheckoutForm extends Customer,Address{delivery:Delivery|'';payment:Payment|''}
export interface OrderItem{sku:string;name:string;size:string;color:string;qty:number;unitPrice:number}
export interface Order{no:string;date:string;eta:string;status:OrderStatus;customer:Customer;address:Address;delivery:Delivery;
 payment:Payment;items:OrderItem[];subtotal:number;discount:number;shipping:number;total:number}
