// ============================================================
// EDIT THIS FILE TO MANAGE PRODUCTS.  All items below are SAMPLE DATA.
// Images: drop a file named after the SKU into src/assets/products/
//   e.g. ARI-M-BOOT-001.jpg  (extra views: ARI-M-BOOT-001_2.jpg, _3.jpg ...)
// ============================================================
import type {Category,Gender,Product} from '../types';

const files=import.meta.glob('../assets/products/*.{jpg,jpeg,png,webp}',{eager:true,query:'?url',import:'default'}) as Record<string,string>;
export const imageUrls=(sku:string):string[]=>Object.entries(files)
  .filter(([p])=>{const n=p.split('/').pop()!.replace(/\.[^.]+$/,'');return n===sku||n.startsWith(sku+'_')})
  .sort(([a],[b])=>a.localeCompare(b)).map(([,u])=>u);

const MATERIALS:Record<Category,string>={Boots:'Full-grain leather upper, rubber outsole, cushioned insole (sample)',Shoes:'Leather and textile upper, rubber sole (sample)',
 Shirts:'100% cotton (sample)',Jackets:'Cotton canvas shell, quilted lining (sample)',Jeans:'98% cotton, 2% elastane denim (sample)',
 Accessories:'Genuine leather (sample)',Clothing:'Soft cotton blend (sample)'};
const CARE:Record<Category,string>={Boots:'Wipe clean with a damp cloth. Condition leather regularly. Air dry away from heat.',Shoes:'Spot clean. Air dry.',
 Shirts:'Machine wash cold, tumble dry low.',Jackets:'Machine wash cold, hang dry.',Jeans:'Wash inside out in cold water.',
 Accessories:'Wipe with a soft dry cloth. Keep away from moisture.',Clothing:'Machine wash cold, tumble dry low.'};

// sku, name, gender, category, price (PHP), salePrice, sizes, colors, flags (N=new F=featured), tags
type Row=[string,string,Gender,Category,number,number|undefined,string,string,string,string[]];
const rows:Row[]=[
 ['ARI-M-BOOT-001','Sample Western Work Boot','men','Boots',8995,7196,'7,8,9,10,11,12','Brown,Black','NF',['western','work']],
 ['ARI-M-SHOE-001','Sample Riding Sneaker','men','Shoes',4995,undefined,'7,8,9,10,11','White,Black','N',['sneaker','casual']],
 ['ARI-M-SHIR-001','Sample Plaid Western Shirt','men','Shirts',2495,undefined,'S,M,L,XL','Tan,White','F',['plaid','western']],
 ['ARI-M-JACK-001','Sample Canvas Ranch Jacket','men','Jackets',6995,5596,'S,M,L,XL','Brown,Black','F',['canvas','outdoor']],
 ['ARI-M-JEAN-001','Sample Straight Cut Jeans','men','Jeans',3995,undefined,'30,32,34,36','Blue,Black','N',['denim']],
 ['ARI-M-ACCS-001','Sample Leather Belt','men','Accessories',1895,undefined,'S,M,L','Brown,Black','',['belt','leather']],
 ['ARI-W-BOOT-001','Sample Tall Riding Boot','women','Boots',9495,7596,'5,6,7,8,9,10','Brown,Black','NF',['equestrian','riding']],
 ['ARI-W-SHOE-001','Sample Leather Loafer','women','Shoes',4595,undefined,'5,6,7,8,9','Tan,Black','N',['loafer']],
 ['ARI-W-SHIR-001','Sample Embroidered Blouse','women','Shirts',2295,undefined,'XS,S,M,L','White,Tan','N',['embroidered']],
 ['ARI-W-JACK-001','Sample Quilted Vest Jacket','women','Jackets',5995,undefined,'XS,S,M,L','Brown,Black','F',['quilted','outdoor']],
 ['ARI-W-JEAN-001','Sample High-Rise Bootcut Jeans','women','Jeans',3795,3036,'26,28,30,32','Blue,Black','',['denim','bootcut']],
 ['ARI-W-ACCS-001','Sample Leather Handbag','women','Accessories',4295,undefined,'One Size','Brown,Tan','NF',['bag','leather']],
 ['ARI-K-BOOT-001','Sample Kids Pull-On Boot','kids','Boots',3995,undefined,'10C,11C,12C,13C,1Y,2Y','Brown,Black','N',['kids','boots']],
 ['ARI-K-BOOT-002','Sample Kids Cowboy Boot','kids','Boots',4295,3436,'10C,11C,12C,13C,1Y,2Y','Tan,Brown','F',['kids','western']],
 ['ARI-K-SHOE-001','Sample Kids Sneaker','kids','Shoes',2995,undefined,'10C,11C,12C,13C,1Y,2Y','White,Blue','',['kids','sneaker']],
 ['ARI-K-CLTH-001','Sample Kids Denim Shirt','kids','Clothing',1695,undefined,'4,6,8,10','Blue,White','N',['kids','denim']],
 ['ARI-K-CLTH-002','Sample Kids Rain Jacket','kids','Clothing',2795,undefined,'4,6,8,10','Tan,Blue','F',['kids','outdoor']],
 ['ARI-K-ACCS-001','Sample Kids Cap','kids','Accessories',995,undefined,'One Size','Brown,Black','',['kids','cap']],
];

export const products:Product[]=rows.map(([sku,name,gender,category,price,salePrice,sizes,colors,flags,tags],i)=>({
 id:sku,sku,name,brand:'ARIAT',gender,category,price,salePrice,tags,
 description:`SAMPLE DATA: replace with your real description. A placeholder ${category.toLowerCase()} item from the ${gender} collection.`,
 variants:sizes.split(',').flatMap((s,si)=>colors.split(',').map((c,ci)=>({size:s,color:c,stock:(si+ci+i)%5===4?0:2+((si*3+ci+i)%6)}))),
 rating:Math.round((3.8+((i*7)%12)/10)*10)/10,reviewCount:12+i*9,materials:MATERIALS[category],care:CARE[category],
 isNew:flags.includes('N'),isFeatured:flags.includes('F')}));
