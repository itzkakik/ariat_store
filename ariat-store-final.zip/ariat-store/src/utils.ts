import type {CartItem,CheckoutForm,Delivery,Payment,Product} from './types';
import {products} from './data/products';

export const FREE_SHIPPING_MIN=5000;
export const SHIPPING:Record<Delivery,number>={standard:150,express:350};
export const DELIVERY:{id:Delivery;label:string;note:string}[]=[
 {id:'standard',label:'Standard Delivery',note:'3-7 business days'},{id:'express',label:'Express Delivery',note:'1-3 business days'}];
export const PAYMENTS:Payment[]=['Cash on Delivery','GCash','Maya','Credit/Debit Card'];
export const COLOR_HEX:Record<string,string>={Brown:'#5C3A21',Black:'#1f1b19',Tan:'#c8a77a',White:'#f7f4ee',Blue:'#3b5b82'};

export const peso=(n:number)=>new Intl.NumberFormat('en-PH',{style:'currency',currency:'PHP'}).format(n);
export const unitPrice=(p:Product)=>p.salePrice!==undefined&&p.salePrice<p.price?p.salePrice:p.price;
export const isSale=(p:Product)=>unitPrice(p)<p.price;
export const discountPct=(p:Product)=>Math.round((1-unitPrice(p)/p.price)*100);
export const stockOf=(p:Product,size:string,color:string)=>p.variants.find(v=>v.size===size&&v.color===color)?.stock??0;
export const totalStock=(p:Product)=>p.variants.reduce((n,v)=>n+v.stock,0);
export const key=(i:CartItem)=>`${i.sku}|${i.size}|${i.color}`;
export const same=(a:CartItem,b:CartItem)=>key(a)===key(b)&&!!a.saved===!!b.saved;
export const find=(sku:string)=>products.find(p=>p.sku===sku);

/** Single source of truth for every number shown in cart, checkout and orders. */
export function totals(items:CartItem[],delivery:Delivery|''){
 let subtotal=0,discount=0;
 for(const i of items){const p=find(i.sku);if(!p)continue;subtotal+=p.price*i.qty;discount+=(p.price-unitPrice(p))*i.qty}
 const net=subtotal-discount;
 const shipping=!items.length?0:delivery==='express'?SHIPPING.express:net>=FREE_SHIPPING_MIN?0:SHIPPING.standard;
 return {subtotal,discount,shipping,total:net+shipping};
}

export function optionError(p:Product|undefined,size:string,color:string,qty:number):string|null{
 if(!p)return 'This product no longer exists.';
 if(!p.variants.some(v=>v.stock>0))return 'This product is out of stock.';
 if(!size&&!color)return 'Please select all required options before adding this product.';
 if(!size)return 'Please select a size.';
 if(!color)return 'Please select a color.';
 if(!Number.isInteger(qty)||qty<1)return 'Please enter a valid quantity.';
 const s=stockOf(p,size,color);
 if(s<=0)return 'This size and color combination is out of stock.';
 if(qty>s)return `Only ${s} left in stock.`;
 return null;
}
export function validateCart(items:CartItem[]):string[]{
 if(!items.length)return ['Your cart is empty.'];
 return items.flatMap(i=>{const p=find(i.sku);const e=optionError(p,i.size,i.color,i.qty);
  return e?[`${p?.name??i.sku} (${i.size}, ${i.color}): ${e}`]:[]});
}

export const validEmail=(e:string)=>/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e.trim());
export type Errors=Partial<Record<keyof CheckoutForm,string>>;
export function validateCheckout(f:CheckoutForm):Errors{
 const e:Errors={};const req=(k:keyof CheckoutForm,m:string)=>{if(!String(f[k]).trim())e[k]=m};
 req('firstName','Please enter your first name.');req('lastName','Please enter your last name.');
 if(!validEmail(f.email))e.email='Please enter a valid email address.';
 if(!/^(\+63|0)9\d{9}$/.test(f.phone.replace(/[\s-]/g,'')))e.phone='Please enter a valid PH mobile number (e.g. 09171234567).';
 req('unit','Please enter your house/unit.');req('street','Please enter your street.');req('barangay','Please enter your barangay.');
 req('city','Please enter your city.');req('province','Please enter your province.');req('country','Please enter your country.');
 if(!/^\d{4}$/.test(f.postal.trim()))e.postal='Please enter a 4-digit postal code.';
 if(!f.delivery)e.delivery='Please select a delivery method.';
 if(!f.payment)e.payment='Please select a payment method.';
 return e;
}
