import {createContext,useContext,useEffect,useState,type ReactNode} from 'react';
import type {CartItem,Order} from './types';
import {find,optionError,same,stockOf,key} from './utils';

export function useLocal<T>(k:string,init:T){
 const [v,setV]=useState<T>(()=>{try{const s=localStorage.getItem(k);return s?JSON.parse(s) as T:init}catch{return init}});
 useEffect(()=>{try{localStorage.setItem(k,JSON.stringify(v))}catch{/* storage unavailable */}},[k,v]);
 return [v,setV] as const;
}
type Kind='success'|'error'|'warning'|'info';type Theme='light'|'dark';
interface ToastMsg{id:number;kind:Kind;msg:string}
interface Ctx{theme:Theme;toggleTheme():void;cart:CartItem[];addToCart(sku:string,size:string,color:string,qty:number):string|null;
 setQty(i:CartItem,q:number):void;remove(i:CartItem):void;clearCart():void;toggleSave(i:CartItem):void;
 wishlist:string[];toggleWish(sku:string):void;orders:Order[];placeOrder(o:Omit<Order,'no'|'date'|'status'>):Order;
 toasts:ToastMsg[];toast(k:Kind,m:string):void;resetDemo():void}
const C=createContext<Ctx|null>(null);
export const useApp=()=>{const c=useContext(C);if(!c)throw new Error('useApp must be used inside AppProvider');return c};

export function AppProvider({children}:{children:ReactNode}){
 const [theme,setTheme]=useLocal<Theme>('ari-theme',window.matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light');
 const [cart,setCart]=useLocal<CartItem[]>('ari-cart',[]);
 const [wishlist,setWish]=useLocal<string[]>('ari-wish',[]);
 const [orders,setOrders]=useLocal<Order[]>('ari-orders',[]);
 const [toasts,setToasts]=useState<ToastMsg[]>([]);
 useEffect(()=>{document.documentElement.dataset.theme=theme},[theme]);
 const toast=(kind:Kind,msg:string)=>{const id=Date.now()+Math.random();setToasts(t=>[...t,{id,kind,msg}]);
  setTimeout(()=>setToasts(t=>t.filter(x=>x.id!==id)),3500)};

 const addToCart=(sku:string,size:string,color:string,qty:number)=>{
  const p=find(sku);const ex=cart.find(i=>!i.saved&&i.sku===sku&&i.size===size&&i.color===color);
  const err=optionError(p,size,color,qty+(ex?.qty??0));
  if(err){toast('error',ex&&err.startsWith('Only')?`${err} You already have ${ex.qty} in your cart.`:err);return err}
  setCart(c=>ex?c.map(i=>!i.saved&&key(i)===key(ex)?{...i,qty:i.qty+qty}:i):[...c,{sku,size,color,qty}]);
  toast('success','Product added to cart.');return null;
 };
 const setQty=(it:CartItem,q:number)=>{
  const p=find(it.sku);const max=p?Math.max(1,stockOf(p,it.size,it.color)):1;
  if(q>max)toast('warning',`Only ${max} item${max>1?'s':''} remaining.`);
  const n=Math.max(1,Math.min(q,max));setCart(c=>c.map(i=>same(i,it)?{...i,qty:n}:i));
 };
 const remove=(it:CartItem)=>{setCart(c=>c.filter(i=>!same(i,it)));toast('info','Item removed.')};
 const clearCart=()=>{setCart(c=>c.filter(i=>i.saved));toast('info','Cart cleared.')};
 const toggleSave=(it:CartItem)=>setCart(c=>{
  const rest=c.filter(i=>!same(i,it));const tgt=rest.find(i=>key(i)===key(it)&&!!i.saved===!it.saved);
  return tgt?rest.map(i=>i===tgt?{...i,qty:i.qty+it.qty}:i):[...rest,{...it,saved:!it.saved}];
 });
 const toggleWish=(sku:string)=>{const has=wishlist.includes(sku);setWish(w=>has?w.filter(x=>x!==sku):[...w,sku]);
  toast('success',has?'Removed from wishlist.':'Added to wishlist.')};
 const placeOrder=(o:Omit<Order,'no'|'date'|'status'>)=>{
  const d=new Date();
  const full:Order={...o,no:`ARI-${d.getFullYear()}-${String(orders.length+125).padStart(5,'0')}`,date:d.toISOString(),status:'Processing'};
  setOrders(x=>[full,...x]);setCart(c=>c.filter(i=>i.saved));return full;
 };
 const resetDemo=()=>{setCart([]);setWish([]);setOrders([]);toast('info','Demo data cleared.')};
 return <C.Provider value={{theme,toggleTheme:()=>setTheme(theme==='dark'?'light':'dark'),cart,addToCart,setQty,remove,clearCart,toggleSave,
  wishlist,toggleWish,orders,placeOrder,toasts,toast,resetDemo}}>{children}</C.Provider>;
}
