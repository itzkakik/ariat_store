import {Component,StrictMode,type ReactNode} from 'react';import {createRoot} from 'react-dom/client';import {HashRouter} from 'react-router-dom';
import App from './App';import {AppProvider} from './state';import './styles.css';

/** Shows the real error on screen instead of a blank page, and lets you wipe saved demo data. */
class Boundary extends Component<{children:ReactNode},{err?:Error}>{
 state:{err?:Error}={};
 static getDerivedStateFromError(err:Error){return {err}}
 render(){
  if(!this.state.err)return this.props.children;
  return <div style={{padding:24,color:'#ff8f85',font:'14px monospace'}}><h2>Something went wrong</h2>
   <pre style={{whiteSpace:'pre-wrap'}}>{this.state.err.message}{'\n'}{this.state.err.stack}</pre>
   <button onClick={()=>{localStorage.clear();location.reload()}}>Clear saved data and reload</button></div>;
 }
}
createRoot(document.getElementById('root')!).render(<StrictMode><Boundary><HashRouter><AppProvider><App/></AppProvider></HashRouter></Boundary></StrictMode>);
