import {useEffect} from 'react';
import {Route,Routes,useLocation} from 'react-router-dom';
import {Footer,Navbar,Toasts} from './components';
import {About,Account,CartPage,Checkout,Detail,Home,Listing,Success} from './pages';
import {isSale} from './utils';

export default function App(){
 const {pathname}=useLocation();useEffect(()=>window.scrollTo(0,0),[pathname]);
 return <><a className="skip" href="#main">Skip to content</a><Navbar/><div id="main">
  <Routes>
   <Route path="/" element={<Home/>}/><Route path="/about" element={<About/>}/>
   <Route path="/new-arrivals" element={<Listing title="New Arrivals" filter={p=>!!p.isNew}/>}/>
   <Route path="/featured" element={<Listing title="Featured" filter={p=>!!p.isFeatured}/>}/>
   <Route path="/sale" element={<Listing title="Sale" filter={isSale}/>}/>
   <Route path="/men" element={<Listing title="Men" gender="men"/>}/><Route path="/women" element={<Listing title="Women" gender="women"/>}/>
   <Route path="/kids" element={<Listing title="Kids" gender="kids"/>}/><Route path="/search" element={<Listing title="Search"/>}/>
   <Route path="/product/:sku" element={<Detail/>}/><Route path="/cart" element={<CartPage/>}/><Route path="/checkout" element={<Checkout/>}/>
   <Route path="/order-success/:no" element={<Success/>}/><Route path="/account" element={<Account/>}/>
   <Route path="*" element={<main className="wrap"><h1>Page not found</h1></main>}/>
  </Routes></div><Footer/><Toasts/></>;
}
