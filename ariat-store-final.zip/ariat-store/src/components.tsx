import {useEffect,useState,type FormEvent,type ReactNode} from 'react';
import {Link,NavLink,useNavigate} from 'react-router-dom';
import {useApp} from './state';
import type {Product} from './types';
import {imageUrls} from './data/products';
import {peso,unitPrice,isSale,discountPct,validEmail,totalStock} from './utils';

export function Navbar(){
 const {cart,wishlist,theme,toggleTheme}=useApp();const nav=useNavigate();
 const [open,setOpen]=useState(false);const [small,setSmall]=useState(false);const [q,setQ]=useState('');
 useEffect(()=>{const f=()=>setSmall(window.scrollY>40);window.addEventListener('scroll',f,{passive:true});return()=>window.removeEventListener('scroll',f)},[]);
 const count=cart.filter(i=>!i.saved).reduce((n,i)=>n+i.qty,0);
 const links:[string,string][]=[['/','Home'],['/about','About'],['/new-arrivals','New Arrivals'],['/featured','Featured'],['/men','Men'],['/women','Women'],['/kids','Kids'],['/sale','Sale']];
 const search=(e:FormEvent)=>{e.preventDefault();if(q.trim()){nav(`/search?q=${encodeURIComponent(q.trim())}`);setOpen(false)}};
 return <header className={`nav${small?' small':''}`}><div className="nav-in">
  <Link to="/" className="logo" aria-label="ARIAT Prototype Store, home">ARIAT<small>Prototype Store</small></Link>
  <nav className={`links${open?' open':''}`} aria-label="Main">
   {links.map(([to,l])=><NavLink key={to} to={to} end={to==='/'} onClick={()=>setOpen(false)}>{l}</NavLink>)}
   <form onSubmit={search} role="search"><input aria-label="Search products" placeholder="Search products" value={q} onChange={e=>setQ(e.target.value)}/></form>
  </nav>
  <div className="actions">
   <button className="icon" aria-label={`Switch to ${theme==='dark'?'light':'dark'} mode`} onClick={toggleTheme}>{theme==='dark'?'☀':'☾'}</button>
   <Link className="icon" to="/account?tab=wishlist" aria-label={`Wishlist, ${wishlist.length} items`}>♡</Link>
   <Link className="icon" to="/account" aria-label="Account">☺</Link>
   <Link className="icon" to="/cart" aria-label={`Cart, ${count} items`}>🛒{count>0&&<b key={count} className="badge">{count}</b>}</Link>
   <button className="icon menu-btn" aria-expanded={open} aria-label="Toggle menu" onClick={()=>setOpen(!open)}>☰</button>
  </div></div></header>;
}

function Newsletter(){
 const [e,setE]=useState('');const [msg,setMsg]=useState('');const [ok,setOk]=useState(false);
 const sub=(ev:FormEvent)=>{ev.preventDefault();if(!validEmail(e)){setOk(false);setMsg('Please enter a valid email address.');return}
  setOk(true);setMsg('Thanks for subscribing!');setE('')};
 return <form onSubmit={sub} noValidate className="news"><label htmlFor="nl">Get new arrivals in your inbox</label>
  <div className="row"><input id="nl" type="email" value={e} onChange={x=>setE(x.target.value)} placeholder="you@example.com"/><button className="btn">Subscribe</button></div>
  {msg&&<p role="status" className={ok?'ok':'err'}>{msg}</p>}</form>;
}
export function Footer(){
 const cols:[string,[string,string][]][]=[
  ['Customer Service',[['Contact Us','#'],['Shipping','#'],['Returns','#'],['FAQ','#']]],
  ['About',[['About Us','/about'],['Our Story','/about'],['Careers','#']]],
  ['Shopping',[['Men','/men'],['Women','/women'],['Kids','/kids'],['New Arrivals','/new-arrivals'],['Sale','/sale']]],
  ['Legal',[['Privacy Policy','#'],['Terms & Conditions','#']]]];
 return <footer className="foot"><div className="wrap foot-grid">
  {cols.map(([h,ls])=><div key={h}><h3>{h}</h3><ul>{ls.map(([l,to])=><li key={l}>{to.startsWith('/')?<Link to={to}>{l}</Link>:<a href={to}>{l}</a>}</li>)}</ul></div>)}
  <div><h3>Follow</h3><p className="social"><a href="#" aria-label="Facebook">Facebook</a> <a href="#" aria-label="Instagram">Instagram</a> <a href="#" aria-label="YouTube">YouTube</a></p><Newsletter/></div>
  </div><div className="wrap legal"><p>Demo store, not an official Ariat site. Payments are simulated. All products are sample data.</p><p>© {new Date().getFullYear()} ARIAT Prototype Store</p></div></footer>;
}

export function ProductImage({p,src}:{p:Product;src?:string}){
 const s=src??imageUrls(p.sku)[0];
 return s?<img src={s} alt={p.name} loading="lazy"/>:<div className="ph" role="img" aria-label={`${p.name}, image coming soon`}><span>Image coming soon</span><small>{p.sku}</small></div>;
}
export const Stars=({p}:{p:Product})=><span className="stars" aria-label={`Rated ${p.rating.toFixed(1)} out of 5 from ${p.reviewCount} reviews`}>{'★'.repeat(Math.round(p.rating))}{'☆'.repeat(5-Math.round(p.rating))} <small>({p.reviewCount})</small></span>;
export function Price({p}:{p:Product}){
 return isSale(p)?<p className="price"><del>{peso(p.price)}</del> <strong>{peso(unitPrice(p))}</strong> <span className="off">{discountPct(p)}% OFF</span></p>
  :<p className="price"><strong>{peso(p.price)}</strong></p>;
}
export function ProductCard({p}:{p:Product}){
 const {wishlist,toggleWish,addToCart,toast}=useApp();const nav=useNavigate();
 const wished=wishlist.includes(p.sku);const left=totalStock(p);
 const quick=()=>{if(p.variants.length===1)addToCart(p.sku,p.variants[0].size,p.variants[0].color,1);
  else{toast('info','Please choose a size and color first.');nav(`/product/${p.sku}`)}};
 return <article className="card">
  <div className="card-img"><Link to={`/product/${p.sku}`} aria-label={`View ${p.name}`}><ProductImage p={p}/></Link>
   <div className="badges">{p.isNew&&<span className="b new">New</span>}{isSale(p)&&<span className="b sale">Sale</span>}{left===0&&<span className="b out">Sold out</span>}</div>
   <button className="wish" aria-pressed={wished} aria-label={wished?`Remove ${p.name} from wishlist`:`Add ${p.name} to wishlist`} onClick={()=>toggleWish(p.sku)}>{wished?'♥':'♡'}</button></div>
  <div className="card-body"><small>{p.gender} · {p.category}</small>
   <h3><Link to={`/product/${p.sku}`}>{p.name}</Link></h3><Stars p={p}/><Price p={p}/>
   {left>0&&left<=10&&<small className="low">Only {left} left</small>}
   <button className="btn ghost" disabled={left===0} onClick={quick}>Quick Add</button></div></article>;
}

export function Modal({title,onClose,children}:{title:string;onClose:()=>void;children:ReactNode}){
 useEffect(()=>{const f=(e:KeyboardEvent)=>{if(e.key==='Escape')onClose()};window.addEventListener('keydown',f);return()=>window.removeEventListener('keydown',f)},[onClose]);
 return <div className="overlay" onClick={onClose}><div className="modal" role="dialog" aria-modal="true" aria-label={title} onClick={e=>e.stopPropagation()}><h2>{title}</h2>{children}</div></div>;
}
export function Confirm({title,message,label,onYes,onNo}:{title:string;message:string;label:string;onYes():void;onNo():void}){
 return <Modal title={title} onClose={onNo}><p>{message}</p><div className="row end"><button className="btn ghost" onClick={onNo}>Cancel</button><button className="btn" autoFocus onClick={onYes}>{label}</button></div></Modal>;
}
export function Toasts(){const {toasts}=useApp();
 return <div className="toasts" aria-live="polite">{toasts.map(t=><div key={t.id} className={`toast ${t.kind}`}>{t.msg}</div>)}</div>}
