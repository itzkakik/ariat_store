import {useState} from 'react';
import {Link,useNavigate,useParams,useSearchParams} from 'react-router-dom';
import {useApp,useLocal} from './state';
import {ProductCard,ProductImage,Price,Stars,Modal,Confirm} from './components';
import {imageUrls,products} from './data/products';
import type {CartItem,CheckoutForm,Gender,Order,Product} from './types';
import {COLOR_HEX,DELIVERY,PAYMENTS,find,isSale,optionError,peso,stockOf,totals,unitPrice,validateCart,validateCheckout,type Errors} from './utils';

const Grid=({list}:{list:Product[]})=><div className="grid">{list.map(p=><ProductCard key={p.sku} p={p}/>)}</div>;
const Section=({title,to,list}:{title:string;to:string;list:Product[]})=>
 <section className="wrap"><div className="sec-head"><h2>{title}</h2><Link to={to}>View all</Link></div><Grid list={list.slice(0,4)}/></section>;

export function Home(){return <>
 <section className="hero"><div className="hero-in"><h1>Built for the Ride.<br/>Designed for Every Day.</h1>
  <p>Boots, apparel and accessories made for the arena, the ranch and the road home.</p>
  <div className="row"><Link className="btn" to="/men">Shop Men</Link><Link className="btn light" to="/women">Shop Women</Link></div></div></section>
 <Section title="New Arrivals" to="/new-arrivals" list={products.filter(p=>p.isNew)}/>
 <Section title="Featured" to="/featured" list={products.filter(p=>p.isFeatured)}/>
 <section className="wrap teaser"><h2>Made to be worn hard</h2><p>Leather that softens, stitching that holds, and fits tested in the saddle and on the street.</p><Link className="btn ghost" to="/about">Read our story</Link></section></>}

export const About=()=><main className="wrap prose"><h1>Our story</h1>
 <p>ARIAT Prototype Store is a demo storefront inspired by equestrian and outdoor craft. Replace this text with your real brand story.</p>
 <h2>Craftsmanship</h2><p>Full-grain leathers, reinforced stitching and honest materials. Sample copy only.</p>
 <h2>Performance</h2><p>Gear designed for long days: comfort in the stirrup, grip on uneven ground. Sample copy only.</p>
 <h2>Lifestyle</h2><p>From the ranch to the city, pieces that work as hard as you do. Sample copy only.</p></main>;

export function Listing({title,gender,filter}:{title:string;gender?:Gender;filter?:(p:Product)=>boolean}){
 const [sp]=useSearchParams();const q=(sp.get('q')??'').toLowerCase().trim();
 const [cat,setCat]=useState('');const [color,setColor]=useState('');const [maxP,setMaxP]=useState(0);const [inStock,setInStock]=useState(false);const [sort,setSort]=useState('newest');
 const base=products.filter(p=>(!gender||p.gender===gender)&&(!filter||filter(p))&&(!q||[p.name,p.category,p.brand,...p.tags].join(' ').toLowerCase().includes(q)));
 const cats=[...new Set(base.map(p=>p.category))];const colors=[...new Set(base.flatMap(p=>p.variants.map(v=>v.color)))];
 const list=base.filter(p=>(!cat||p.category===cat)&&(!color||p.variants.some(v=>v.color===color))&&(!maxP||unitPrice(p)<=maxP)&&(!inStock||p.variants.some(v=>v.stock>0)))
  .sort((a,b)=>sort==='low'?unitPrice(a)-unitPrice(b):sort==='high'?unitPrice(b)-unitPrice(a):sort==='popular'?b.reviewCount-a.reviewCount:sort==='rating'?b.rating-a.rating:Number(!!b.isNew)-Number(!!a.isNew));
 return <main className="wrap"><h1>{q?`Results for "${q}"`:title}</h1>
  <div className="filters" role="group" aria-label="Filters">
   <label>Category<select value={cat} onChange={e=>setCat(e.target.value)}><option value="">All</option>{cats.map(c=><option key={c}>{c}</option>)}</select></label>
   <label>Color<select value={color} onChange={e=>setColor(e.target.value)}><option value="">All</option>{colors.map(c=><option key={c}>{c}</option>)}</select></label>
   <label>Max price<select value={maxP} onChange={e=>setMaxP(Number(e.target.value))}><option value={0}>Any</option>{[3000,5000,8000].map(n=><option key={n} value={n}>{peso(n)}</option>)}</select></label>
   <label>Sort<select value={sort} onChange={e=>setSort(e.target.value)}><option value="newest">Newest</option><option value="popular">Popularity</option><option value="rating">Rating</option><option value="low">Price: low to high</option><option value="high">Price: high to low</option></select></label>
   <label className="chk"><input type="checkbox" checked={inStock} onChange={e=>setInStock(e.target.checked)}/>In stock only</label></div>
  <p className="muted" role="status">{list.length} product{list.length!==1&&'s'}</p>
  {list.length?<Grid list={list}/>:<div className="empty"><h2>No products found.</h2><p>Try a different search or clear a filter. Browse <Link to="/men">Men</Link>, <Link to="/women">Women</Link> or <Link to="/kids">Kids</Link>.</p></div>}</main>;
}

const FOOT=[['5','23.0'],['7','25.0'],['9','27.0'],['11','29.0']];const BODY=[['S','86-91'],['M','96-101'],['L','106-111'],['XL','116-121']];
export function Detail(){
 const {sku}=useParams();const p=find(sku??'');const app=useApp();
 const [size,setSize]=useState('');const [color,setColor]=useState('');const [qty,setQty]=useState(1);const [err,setErr]=useState('');
 const [guide,setGuide]=useState(false);const [light,setLight]=useState(false);const [img,setImg]=useState(0);const [origin,setOrigin]=useState('50% 50%');
 if(!p)return <main className="wrap"><h1>Product not found</h1><p>This product may have been removed.</p><Link className="btn" to="/">Back to home</Link></main>;
 const imgs=imageUrls(p.sku);const sizes=[...new Set(p.variants.map(v=>v.size))];const colors=[...new Set(p.variants.map(v=>v.color))];
 const avail=(s:string,c:string)=>p.variants.some(v=>(!s||v.size===s)&&(!c||v.color===c)&&v.stock>0);
 const max=size&&color?stockOf(p,size,color):10;const footwear=p.category==='Boots'||p.category==='Shoes';
 const pick=(s:string,c:string)=>{setSize(s);setColor(c);setQty(1);setErr('')};
 const add=()=>setErr(app.addToCart(p.sku,size,color,qty)??'');
 return <main className="wrap detail"><div>
  <div className="zoom" onMouseMove={e=>{const r=e.currentTarget.getBoundingClientRect();setOrigin(`${(e.clientX-r.left)/r.width*100}% ${(e.clientY-r.top)/r.height*100}%`)}}
   style={{['--o' as string]:origin}} onClick={()=>imgs.length&&setLight(true)}><ProductImage p={p} src={imgs[img]}/></div>
  {imgs.length>1&&<div className="thumbs">{imgs.map((u,i)=><button key={u} aria-label={`Show image ${i+1}`} aria-current={i===img} onClick={()=>setImg(i)}><img src={u} alt=""/></button>)}</div>}
  {imgs.length>0&&<small className="muted">Hover to zoom, click for fullscreen.</small>}</div>
  <div><p className="muted">{p.gender} · {p.category} · SKU {p.sku}</p><h1>{p.name}</h1><Stars p={p}/><Price p={p}/><small className="muted">VAT included</small>
   <p>{p.description}</p>
   <fieldset><legend>Size <button className="link" onClick={()=>setGuide(true)}>Size guide</button></legend><div className="opts">
    {sizes.map(s=><button key={s} className="opt-btn" aria-pressed={size===s} disabled={!avail(s,color)} onClick={()=>pick(s,color)}>{s}</button>)}</div></fieldset>
   <fieldset><legend>Color{color&&`: ${color}`}</legend><div className="opts">
    {colors.map(c=><button key={c} className="swatch" aria-label={c} aria-pressed={color===c} disabled={!avail(size,c)} style={{background:COLOR_HEX[c]??'#999'}} onClick={()=>pick(size,c)}/>)}</div></fieldset>
   <fieldset><legend>Quantity</legend><div className="qty"><button aria-label="Decrease quantity" disabled={qty<=1} onClick={()=>setQty(qty-1)}>−</button><span aria-live="polite">{qty}</span>
    <button aria-label="Increase quantity" disabled={qty>=max} onClick={()=>setQty(qty+1)}>+</button></div>
    {size&&color&&max<=3&&max>0&&<p className="warn">Only {max} left in stock</p>}{size&&color&&max===0&&<p className="err">Out of stock</p>}</fieldset>
   {err&&<p className="err" role="alert">❌ {err}</p>}
   <button className="btn big" onClick={add} disabled={!p.variants.some(v=>v.stock>0)}>Add to Cart</button>
   <details open><summary>Materials</summary><p>{p.materials}</p></details><details><summary>Care instructions</summary><p>{p.care}</p></details></div>
  {guide&&<Modal title="Size guide (sample chart)" onClose={()=>setGuide(false)}><table><thead><tr><th>Size</th><th>{footwear?'Foot length (cm)':'Chest (cm)'}</th></tr></thead>
   <tbody>{(footwear?FOOT:BODY).map(([a,b])=><tr key={a}><td>{a}</td><td>{b}</td></tr>)}</tbody></table><div className="row end"><button className="btn" onClick={()=>setGuide(false)}>Close</button></div></Modal>}
  {light&&<Modal title={p.name} onClose={()=>setLight(false)}><img className="lightbox" src={imgs[img]} alt={p.name}/><div className="row end"><button className="btn" onClick={()=>setLight(false)}>Close</button></div></Modal>}</main>;
}

export function CartPage(){
 const {cart,setQty,remove,clearCart,toggleSave}=useApp();const nav=useNavigate();
 const [conf,setConf]=useState<{item?:CartItem}|null>(null);const [errs,setErrs]=useState<string[]>([]);
 const items=cart.filter(i=>!i.saved);const saved=cart.filter(i=>i.saved);const t=totals(items,'standard');
 const go=()=>{const e=validateCart(items);setErrs(e);if(!e.length)nav('/checkout')};
 const row=(i:CartItem)=>{const p=find(i.sku);const s=p?stockOf(p,i.size,i.color):0;
  return <li key={`${i.sku}${i.size}${i.color}${i.saved}`} className="line">
   <div className="thumb">{p&&<ProductImage p={p}/>}</div>
   <div><h3>{p?<Link to={`/product/${p.sku}`}>{p.name}</Link>:'Product no longer available'}</h3><p className="muted">Size {i.size} · {i.color}</p>
    {p&&<p>{peso(unitPrice(p))}{isSale(p)&&<del> {peso(p.price)}</del>}</p>}
    <p className={s<i.qty?'err':s<=3?'warn':'ok'}>{s<i.qty?(s===0?'Out of stock':`Only ${s} available`):s<=3?`Only ${s} left`:'In stock'}</p>
    <div className="row">{!i.saved&&<div className="qty"><button aria-label="Decrease quantity" disabled={i.qty<=1} onClick={()=>setQty(i,i.qty-1)}>−</button><span>{i.qty}</span><button aria-label="Increase quantity" onClick={()=>setQty(i,i.qty+1)}>+</button></div>}
     <button className="link" onClick={()=>toggleSave(i)}>{i.saved?'Move to cart':'Save for later'}</button><button className="link" onClick={()=>setConf({item:i})}>Remove</button></div></div>
   <strong>{p?peso(unitPrice(p)*i.qty):'-'}</strong></li>};
 return <main className="wrap"><h1>Shopping cart</h1>
  {!items.length?<div className="empty"><h2>Your cart is empty.</h2><Link className="btn" to="/">Continue shopping</Link></div>:
  <div className="split"><div><ul className="lines">{items.map(row)}</ul><button className="link" onClick={()=>setConf({})}>Clear cart</button></div>
   <aside className="summary"><h2>Order summary</h2><Totals t={t}/><p className="muted">Free standard shipping from ₱5,000. VAT included.</p>
    {errs.length>0&&<ul className="err" role="alert">{errs.map(e=><li key={e}>❌ {e}</li>)}</ul>}<button className="btn big" onClick={go}>Proceed to checkout</button></aside></div>}
  {saved.length>0&&<><h2>Saved for later</h2><ul className="lines">{saved.map(row)}</ul></>}
  {conf&&<Confirm title={conf.item?'Remove item':'Clear cart'} message={conf.item?'Are you sure you want to remove this item?':'Are you sure you want to clear your cart?'} label={conf.item?'Remove':'Clear cart'}
   onNo={()=>setConf(null)} onYes={()=>{conf.item?remove(conf.item):clearCart();setConf(null)}}/>}</main>;
}
function Totals({t}:{t:{subtotal:number;discount:number;shipping:number;total:number}}){
 return <dl className="totals"><dt>Subtotal</dt><dd>{peso(t.subtotal)}</dd><dt>Discount</dt><dd>-{peso(t.discount)}</dd><dt>Shipping</dt><dd>{t.shipping?peso(t.shipping):'Free'}</dd><dt>Total</dt><dd><strong>{peso(t.total)}</strong></dd></dl>}

const EMPTY:CheckoutForm={firstName:'',lastName:'',email:'',phone:'',unit:'',street:'',barangay:'',city:'',province:'',postal:'',country:'Philippines',delivery:'',payment:''};
const STEPS:{name:string;fields:(keyof CheckoutForm)[]}[]=[
 {name:'Customer',fields:['firstName','lastName','email','phone']},
 {name:'Shipping',fields:['unit','street','barangay','city','province','postal','country']},
 {name:'Delivery',fields:['delivery']},{name:'Payment',fields:['payment']},{name:'Review',fields:[]}];
const LABELS:Partial<Record<keyof CheckoutForm,string>>={firstName:'First name',lastName:'Last name',email:'Email',phone:'Phone number',unit:'House/Unit',street:'Street',barangay:'Barangay',city:'City',province:'Province',postal:'Postal code',country:'Country'};

export function Checkout(){
 const {cart,placeOrder,toast}=useApp();const nav=useNavigate();
 const [form,setForm]=useLocal<CheckoutForm>('ari-checkout',EMPTY);
 const [step,setStep]=useState(0);const [errors,setErrors]=useState<Errors>({});const [agree,setAgree]=useState(false);const [ask,setAsk]=useState(false);
 const items=cart.filter(i=>!i.saved);const cartErrs=validateCart(items);
 const set=(k:keyof CheckoutForm,v:string)=>{setForm({...form,[k]:v});setErrors(e=>({...e,[k]:undefined}))};
 if(cartErrs.length)return <main className="wrap"><h1>Checkout</h1><div className="empty"><h2>Please fix your cart first.</h2>
  <ul className="err">{cartErrs.map(e=><li key={e}>❌ {e}</li>)}</ul><Link className="btn" to="/cart">Back to cart</Link></div></main>;
 const t=totals(items,form.delivery);
 const next=()=>{const all=validateCheckout(form);const e:Errors={};STEPS[step].fields.forEach(f=>{if(all[f])e[f]=all[f]});setErrors(e);
  if(Object.keys(e).length){toast('error','Please fix the highlighted fields.');return}setStep(step+1)};
 const place=()=>{setAsk(false);const all=validateCheckout(form);
  if(Object.keys(all).length||validateCart(items).length||!agree||!form.delivery||!form.payment){setErrors(all);toast('error','Order could not be placed. Please review your details.');return}
  const {firstName,lastName,email,phone,unit,street,barangay,city,province,postal,country,delivery,payment}=form;
  const o=placeOrder({customer:{firstName,lastName,email,phone},address:{unit,street,barangay,city,province,postal,country},delivery,payment,
   items:items.flatMap(i=>{const p=find(i.sku);return p?[{sku:i.sku,name:p.name,size:i.size,color:i.color,qty:i.qty,unitPrice:unitPrice(p)}]:[]}),
   ...totals(items,delivery),eta:new Date(Date.now()+(delivery==='express'?3:7)*864e5).toISOString()});
  nav(`/order-success/${o.no}`);toast('info','Your order is being processed.');};
 const field=(k:keyof CheckoutForm,type='text')=><div className="field" key={k}><label htmlFor={k}>{LABELS[k]}</label>
  <input id={k} type={type} value={form[k]} onChange={e=>set(k,e.target.value)} aria-invalid={!!errors[k]} aria-describedby={errors[k]?`${k}-e`:undefined}/>
  {errors[k]&&<p id={`${k}-e`} className="err" role="alert">❌ {errors[k]}</p>}</div>;
 return <main className="wrap"><h1>Checkout</h1><p className="notice">Prototype only: no real payment is processed.</p>
  <ol className="steps" aria-label="Checkout progress">{STEPS.map((s,i)=><li key={s.name} aria-current={i===step?'step':undefined} className={i<=step?'on':''}>{s.name}</li>)}</ol>
  <div className="split"><section>
   {step===0&&<>{field('firstName')}{field('lastName')}{field('email','email')}{field('phone','tel')}</>}
   {step===1&&<>{STEPS[1].fields.map(f=>field(f))}</>}
   {step===2&&<fieldset><legend>Delivery method</legend>{DELIVERY.map(d=><label key={d.id} className="opt"><input type="radio" name="delivery" checked={form.delivery===d.id} onChange={()=>set('delivery',d.id)}/>
    {d.label} <span className="muted">{d.note}</span></label>)}{errors.delivery&&<p className="err" role="alert">❌ {errors.delivery}</p>}</fieldset>}
   {step===3&&<fieldset><legend>Payment method (demo)</legend>{PAYMENTS.map(m=><label key={m} className="opt"><input type="radio" name="payment" checked={form.payment===m} onChange={()=>set('payment',m)}/>{m}</label>)}
    {errors.payment&&<p className="err" role="alert">❌ {errors.payment}</p>}</fieldset>}
   {step===4&&<div className="review"><h2>Review your order</h2>
    <h3>Customer</h3><p>{form.firstName} {form.lastName}<br/>{form.email}<br/>{form.phone}</p>
    <h3>Shipping</h3><p>{form.unit} {form.street}, {form.barangay}, {form.city}, {form.province} {form.postal}, {form.country}</p>
    <p>{DELIVERY.find(d=>d.id===form.delivery)?.label} · {form.payment}</p>
    <h3>Items</h3><ul>{items.map(i=><li key={`${i.sku}${i.size}${i.color}`}>{find(i.sku)?.name}, {i.size}, {i.color}, ×{i.qty}: {peso(unitPrice(find(i.sku)!)*i.qty)}</li>)}</ul>
    <label className="opt"><input type="checkbox" checked={agree} onChange={e=>setAgree(e.target.checked)}/>I confirm that the information above is correct.</label></div>}
   <div className="row">{step>0&&<button className="btn ghost" onClick={()=>setStep(step-1)}>Back</button>}
    {step<4?<button className="btn" onClick={next}>Continue</button>:<button className="btn" disabled={!agree} onClick={()=>setAsk(true)}>Place Order</button>}</div></section>
   <aside className="summary"><h2>Summary</h2><Totals t={t}/></aside></div>
  {ask&&<Confirm title="Please confirm your order" message="Are you sure you want to place this order?" label="Confirm Order" onNo={()=>setAsk(false)} onYes={place}/>}</main>;
}

const fmt=(d:string)=>new Date(d).toLocaleDateString('en-PH',{dateStyle:'medium'});
function OrderCard({o}:{o:Order}){return <article className="order"><h3>ORDER #{o.no}</h3><p className="muted">{fmt(o.date)} · Status: <strong>{o.status}</strong></p>
 <ul>{o.items.map(i=><li key={i.sku+i.size+i.color}>{i.name}, {i.size}, {i.color}, ×{i.qty}: {peso(i.unitPrice*i.qty)}</li>)}</ul>
 <Totals t={o}/><p className="muted">Ship to: {o.address.unit} {o.address.street}, {o.address.barangay}, {o.address.city}, {o.address.province} {o.address.postal}<br/>Payment: {o.payment} (demo) · Estimated delivery: {fmt(o.eta)}</p></article>}

export function Success(){const {no}=useParams();const {orders}=useApp();const o=orders.find(x=>x.no===no);
 if(!o)return <main className="wrap"><h1>Order not found</h1><Link className="btn" to="/account?tab=orders">View orders</Link></main>;
 return <main className="wrap prose"><h1>✓ Order successfully placed</h1><OrderCard o={o}/><div className="row"><Link className="btn" to="/account?tab=orders">View Order</Link><Link className="btn ghost" to="/">Continue Shopping</Link></div></main>}

export function Account(){
 const {orders,wishlist,cart,toggleSave,resetDemo,theme,toggleTheme}=useApp();const [sp,setSp]=useSearchParams();const tab=sp.get('tab')??'orders';
 const [ask,setAsk]=useState(false);const [f]=useLocal<CheckoutForm>('ari-checkout',EMPTY);
 const tabs:[string,string][]=[['orders','Orders'],['wishlist','Wishlist'],['saved','Saved Items'],['profile','Profile & Address'],['settings','Settings']];
 const wl=products.filter(p=>wishlist.includes(p.sku));const sv=cart.filter(i=>i.saved);
 return <main className="wrap"><h1>My account</h1><div className="tabs" role="tablist">{tabs.map(([k,l])=><button key={k} role="tab" aria-selected={tab===k} onClick={()=>setSp({tab:k})}>{l}</button>)}</div>
  {tab==='orders'&&(orders.length?orders.map(o=><OrderCard key={o.no} o={o}/>):<div className="empty"><h2>No orders yet.</h2><Link className="btn" to="/">Start shopping</Link></div>)}
  {tab==='wishlist'&&(wl.length?<Grid list={wl}/>:<div className="empty"><h2>Your wishlist is empty.</h2><p>Tap the heart on any product to save it.</p></div>)}
  {tab==='saved'&&(sv.length?<ul className="lines">{sv.map(i=><li key={i.sku+i.size+i.color} className="line"><div>{find(i.sku)?.name}, {i.size}, {i.color}</div><button className="link" onClick={()=>toggleSave(i)}>Move to cart</button></li>)}</ul>:<div className="empty"><h2>No saved items.</h2></div>)}
  {tab==='profile'&&<div className="prose"><p>{f.firstName||'-'} {f.lastName}<br/>{f.email||'No email saved yet'}<br/>{f.phone}</p><p>{f.street?`${f.unit} ${f.street}, ${f.barangay}, ${f.city}, ${f.province} ${f.postal}`:'No address saved yet. It is saved when you start checkout.'}</p></div>}
  {tab==='settings'&&<div className="prose"><button className="btn ghost" onClick={toggleTheme}>Theme: {theme}</button> <button className="btn ghost" onClick={()=>setAsk(true)}>Clear demo data</button></div>}
  {ask&&<Confirm title="Clear demo data" message="This removes your cart, wishlist and demo orders." label="Clear" onNo={()=>setAsk(false)} onYes={()=>{resetDemo();setAsk(false)}}/>}</main>;
}
